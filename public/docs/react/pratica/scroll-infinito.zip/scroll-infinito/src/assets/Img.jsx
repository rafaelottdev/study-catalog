function Img({ src, ref } ) {
    return (
        <>
            <img src={src} alt="img" ref={ref} />
        </>
    )
}

export default Img
