const FavoritesPanel = () => {
    return (
        <div>Favorites</div>
    )
}

export default FavoritesPanel
