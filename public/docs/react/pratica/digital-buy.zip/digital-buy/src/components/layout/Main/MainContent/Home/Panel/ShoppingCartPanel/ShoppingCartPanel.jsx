const ShoppingCartPanel = () => {
    return (
        <div>Shopping cart</div>
    )
}

export default ShoppingCartPanel
