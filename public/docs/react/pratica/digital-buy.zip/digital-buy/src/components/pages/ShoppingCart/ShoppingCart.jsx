const ShoppingCart = () => {
    return (
        <div>Carrinho de Compras</div>
    )
}

export default ShoppingCart
