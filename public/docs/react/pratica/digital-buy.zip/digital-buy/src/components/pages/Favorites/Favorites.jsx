const Favorites = () => {
    return (
        <div>Favoritos</div>
    )
}

export default Favorites
