const NewsPanel = () => {
    return (
        <div>News</div>
    )
}

export default NewsPanel
