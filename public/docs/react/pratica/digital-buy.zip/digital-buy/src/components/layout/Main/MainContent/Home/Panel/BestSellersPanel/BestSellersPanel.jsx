const BestSellersPanel = () => {
    return (
        <div>Best Sellers</div>
    )
}

export default BestSellersPanel
