const Input = ({ type, placeholder, styleType }) => {
    return (
        <>
            <input type={type} placeholder={placeholder} />
        </>
    )
}

export default Input
