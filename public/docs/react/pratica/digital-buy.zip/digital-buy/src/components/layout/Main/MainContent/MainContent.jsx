import Home from "../MainContent/Home/Home"
import Highlights from "../MainContent/Highlights/Highlights"

const MainContent = () => {
    return (
        <>
            <Home />

            <Highlights />
        </>
    )
}

export default MainContent
