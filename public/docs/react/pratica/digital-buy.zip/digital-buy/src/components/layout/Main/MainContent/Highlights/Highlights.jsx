import styles from "./Highlights.module.css"

const Highlights = () => {
    return (
        <section className={styles.highlight_container}>
            <h2>Destaques</h2>            
        </section>
    )
}

export default Highlights
