<template>
    <h1>Mais Vendidos</h1>
</template>

<script>
    export default {
        name: "BestSellers"
    }
</script>
