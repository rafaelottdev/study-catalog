<template>
    <h1>Beleza</h1>
</template>

<script>
    export default {
        name: "Beleza"
    }
</script>
