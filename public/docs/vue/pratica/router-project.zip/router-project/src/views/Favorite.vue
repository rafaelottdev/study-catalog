<template>
    <h1>Favoritos</h1>
</template>

<script>
    export default {
        name: "Favorite"
    }
</script>
