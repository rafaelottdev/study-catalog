<template>
    <h1>Novidades</h1>
</template>

<script>
    export default {
        name: "News"
    }
</script>
