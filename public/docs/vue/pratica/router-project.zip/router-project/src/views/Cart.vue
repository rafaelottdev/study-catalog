<template>
    <h1>Carrinho</h1>
</template>

<script>
    export default {
        name: "Cart"
    }
</script>
