<template>
    <h1>Tecnologia</h1>
</template>

<script>
    export default {
        name: "Tecnologia"
    }
</script>
