<template>
    <h1>Alimentos</h1>
</template>

<script>
    export default {
        name: "Alimentos"
    }
</script>
