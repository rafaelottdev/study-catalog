<template>
    <h1>Moda</h1>
</template>

<script>
    export default {
        name: "Moda"
    }
</script>
