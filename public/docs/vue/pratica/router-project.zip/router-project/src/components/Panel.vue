<template>
    <section class="panel-section">
        <div class="panel-list-container">
            <ul class="panel-list">
                <li>
                    <router-link to="BestSellers">Mais Vendidos</router-link>
                </li>
                <li>
                    <router-link to="News">Novidades</router-link>
                </li>
                <li>
                    <router-link to="Cart">Carrinho</router-link>
                </li>
                <li>
                    <router-link to="Favorite">Favoritos</router-link>
                </li>
            </ul>
        </div>

        <div class="content-container">
            <router-view></router-view>
        </div>
    </section>
</template>

<style scoped>
    .panel-section {
        width: 100%;
        height: calc(100vh - 80px);

        background-color: red;
    }

    .panel-list-container {
        width: 1000px;
        margin: 0 auto;
        padding-top: 50px;

        display: flex;
    }

    .panel-list {
        width: inherit;
        display: flex;
        justify-content: space-between;
    }

    .panel-list > li a {
        padding: 8px 30px;

        border-top-left-radius: 5px;
        border-top-right-radius: 5px;

        font-weight: bold;
        font-size: .9em;
        letter-spacing: 1px;
        text-transform: uppercase;
        font-family: sans-serif;

        cursor: pointer;

        color: white;
        background-color: rgb(95, 23, 23);
        text-decoration: none;
    } 
    
    .content-container {
        width: 1000px;
        height: 80%;

        margin: 0 auto;

        background-color: rgb(95, 23, 23);
    }
    
</style>
