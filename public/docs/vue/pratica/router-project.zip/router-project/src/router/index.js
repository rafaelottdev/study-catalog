import { createRouter, createWebHistory } from "vue-router"
import Panel from "@/components/Panel.vue"
import BestSellers from "@/views/BestSellers.vue"
import Cart from "@/views/Cart.vue"
import Favorite from "@/views/Favorite.vue"
import News from "@/views/News.vue"

import Alimentos from "@/views/Alimentos.vue"
import Moda from "@/views/Moda.vue"
import Beleza from "@/views/Beleza.vue"
import Tecnologia from "@/views/Tecnologia.vue"

const routes = [
    { path: '/', name: 'panel', component: Panel, children: [
        {path: 'bestsellers', component: BestSellers},
        {path: 'news', component: News},
        {path: 'cart', component: Cart},
        {path: 'favorite', component: Favorite},
    ] },

    {path: "/alimentos", component: Alimentos},

    {path: "/moda", component: Moda},

    {path: "/beleza", component: Beleza},

    {path: "/tecnologia", component: Tecnologia}
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
