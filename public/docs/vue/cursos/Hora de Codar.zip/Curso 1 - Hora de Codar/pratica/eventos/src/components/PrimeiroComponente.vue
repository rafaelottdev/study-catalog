<template>
    <MultiplosEventos />
</template>

<script>
    import MultiplosEventos from "./MultiplosEventos.vue"

    export default {
        name: "PrimeiroComponente",
        data() {
            return {

            }
        },
        components: {MultiplosEventos}
    }
</script>   