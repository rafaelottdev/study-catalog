<template>
    <div>
        <!-- <Form /> -->
        <PrimeiroComponente />
    </div>
</template>

<script>
    import Form from "./components/Form/Form.vue"
    import PrimeiroComponente from "./components/PrimeiroComponente.vue"

    export default {
        name: 'App', components: {Form, PrimeiroComponente}
    }
</script>

<style>
    body {
        background-color: black;
        color: white;
    }

    a {
        color: red;
    }

    .teste {
        background-color: black;
    }
</style>
