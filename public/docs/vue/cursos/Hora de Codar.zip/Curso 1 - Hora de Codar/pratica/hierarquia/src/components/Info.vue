<template>
    <div>
        <p>Estou trabalhando no momento.</p>
        <p>Utilizo as seguintes tecnologias:</p>
        <ul>
            <li>javascript</li>
            <li>php</li>
            <li>python</li>
        </ul>
    </div>
</template>

<script>
    export default {
        name: "Info"
    }
</script>
