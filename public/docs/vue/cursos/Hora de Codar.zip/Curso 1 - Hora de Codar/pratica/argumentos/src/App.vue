<template>
    <Info />
</template>

<script>
    import Info from "./components/Info.vue"
    export default {
        name: 'App', components: {Info}
    }
</script>
