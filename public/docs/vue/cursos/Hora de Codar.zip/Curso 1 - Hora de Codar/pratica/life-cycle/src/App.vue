<template>
    <LifeCycle />
</template>

<script>
    import LifeCycle from "./components/LifeCycle.vue"
    export default {
        name: 'App', components: {LifeCycle}
    }
</script>
