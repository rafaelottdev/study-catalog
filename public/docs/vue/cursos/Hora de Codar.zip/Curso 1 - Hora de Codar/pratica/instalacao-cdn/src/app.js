const MyNameApp = {
    data() {
        return {
            name: "Rafael",
            age: 30
        }
    }
}

Vue.createApp(MyNameApp).mount('#app')
