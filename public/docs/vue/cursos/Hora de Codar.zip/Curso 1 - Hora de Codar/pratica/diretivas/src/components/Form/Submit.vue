<template>
    <input type="Submit">
</template>

<script>
    export default {
        name: "Submit"
    }
</script>
