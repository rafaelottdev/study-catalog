<template>
    <input type="text">
</template>

<script>
    export default {
        name: "InputText"
    }
</script>
