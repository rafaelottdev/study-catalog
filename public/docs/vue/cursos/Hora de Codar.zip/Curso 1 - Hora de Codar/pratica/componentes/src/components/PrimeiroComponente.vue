<template>
    <h1>Olá, Mundo!</h1>
</template>

<script>
    export default {name: "PrimeiroComponente"}
</script>
