<template>
   <footer id="footer">
        <p>Make Your Burguer &copy; 2025</p>
   </footer>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>
#footer {
    width: 100%;
    height: 200px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-top: 4px solid #111;
    background-color: #222;
    color: #fcba03;
}
</style>