const returnResult = <T> (result: T): T => result

const question = returnResult<string>('ou')
const numberQuestion = returnResult<number>(3)


